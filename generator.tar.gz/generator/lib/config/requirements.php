<?php

return array(
    'app.shop' => array(
        'strict'  => TRUE,
        'version' => '7.4.0'
    ),
    'php.bcmath' => array(
        'description' => _wp('This extension is used for computing'), 'strict' => true,
    ),
);